INTRO:      a tool to simplify database operations, focus on basic use and easily operate data.

VERSION:    0.1

INCLUDE:    mysql utils

AUTHOR:     rainp1ng

MAIL:       cn-zyp@163.com

GITHUB:     https://github.com/rainp1ng/raindb